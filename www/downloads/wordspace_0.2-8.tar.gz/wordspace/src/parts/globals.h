#ifndef wordspace_globals_h
#define wordspace_globals_h

extern int openmp_threads;

#endif /* wordspace_globals_h */
