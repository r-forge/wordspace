library(testthat)
library(wordspace)

test_check("wordspace", reporter="progress")
# test_file("testthat/test_canonical.R")